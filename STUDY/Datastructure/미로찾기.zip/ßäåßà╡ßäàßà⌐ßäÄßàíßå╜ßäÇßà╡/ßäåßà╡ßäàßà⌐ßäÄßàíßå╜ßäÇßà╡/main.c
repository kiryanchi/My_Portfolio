//
//  main.c
//  미로찾기
//
//  Created by 박기현 on 17/02/2020.
//  Copyright © 2020 박기현. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "pos.h"

#define FORWARD 0
#define EAST 1
#define SOUTH 2
#define WEST 3

#define ROAD 0
#define WALL 1
#define VISITED 2
#define REVISITED 3

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
