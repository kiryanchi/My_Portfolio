//
//  stackADT.h
//  미로찾기
//
//  Created by 박기현 on 17/02/2020.
//  Copyright © 2020 박기현. All rights reserved.
//

#ifndef stackADT_h
#define stackADT_h

#include <stdio.h>
#include "pos.h"

#define INITIAL_SIZE 100
typedef struct Position Item;

struct stack {
    Item *data;
    int top;
};

typedef struct stack * Stack;

void create();
void push(Item i);
Item pop();

#endif /* stackADT_h */
