//
//  stackADT.c
//  미로찾기
//
//  Created by 박기현 on 17/02/2020.
//  Copyright © 2020 박기현. All rights reserved.
//
#include <stdlib.h>
#include "stackADT.h"

struct stack {
    Item *data;
    int top;
};

void terminate(const char *message)
{
    printf("%s\n", message);
    exit(1);
}

Stack create()
{
    Stack stack = (Stack)malloc(sizeof(struct stack));
    if (stack == NULL)
        terminate("Stack creation failed.");
    Item *data = (Item *)malloc(sizeof(Item) * INITIAL_SIZE);
    if (data == NULL)
        terminate("Data creation failed.");
    stack->data = data;
    stack->top = -1;
    return stack;
}

void push(Stack s, Item i)
{
    s->
}

Item pop(Stack s)
{
    
}
